// -----JS CODE-----
//@input Component.Label label

var control = script.label.mainPass.baseTex.control;
var score = 0;
var ballEnter;


script.api.ballIn;
script.api.OnTriggerEnter = function (objectName) {
    if (objectName == "ball" && !script.api.ballIn) {
        score += 1;
        script.api.ballIn = true;
        print("something entered called : " + objectName + "and the state is : " + ballEnter);
    }
    control.text = score.toString();
}



script.api.OnTriggerExit = function(objectName)
{

}