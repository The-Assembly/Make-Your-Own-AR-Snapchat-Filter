// -----JS CODE-----
// @input bool isTrigger
//@input string objectName
// @input float width
// @input float height
// @input float breadth
// @input Component.ScriptComponent detect 
// @input Component.ScriptComponent respReciver

// Refrecne The Variables
script.api.isTrigger = script.isTrigger;
script.api.msgReciver = script.respReciver;
script.api.objectName = script.objectName;

script.api.minX = 0;
script.api.minY = 0;
script.api.minZ = 0;
script.api.maxX = 0;
script.api.maxY = 0;
script.api.maxZ = 0;

// Register AABB Detection
function Register() {
    if (script.detect.api) {
        script.detect.api.AddAABB(script);
    }

}


// Calculation For For Creating Collider Detection
script.api.MinMaxCalcuations = function () {

    var position = script.getSceneObject().getTransform().getWorldPosition();
    var HalfW = script.width / 2.0;
    var HalfH = script.height / 2.0;
    var HalfB = script.breadth / 2.0;

    script.api.minX = position.x - HalfW;
    script.api.minY = position.y - HalfH;
    script.api.minZ = position.z - HalfB;


    script.api.maxX = position.x + HalfW;
    script.api.maxY = position.y + HalfH;
    script.api.maxZ = position.z + HalfB;

}


Register();