// -----JS CODE-----

//@input float mass = 1
//@input float elasticity = 0.3

var velocity = new vec3(0,0,0);

script.api.mass = script.mass;
script.api.velocity = velocity;
script.api.elasticity = script.elasticity;
script.api.makeBounce = false;

script.api.setVelocity = function(direction, power)
{
velocity.x = direction.x * power;
velocity.y = direction.y * power;
velocity.z = direction.z * power;
} 